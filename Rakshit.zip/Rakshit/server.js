const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

// MySQL connection setup
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'rags0101',
    database: 'sun_lab_access'
});

db.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL database.');
});

// Route: Home page (Admin GUI)
app.get('/', (req, res) => {
    res.render('index');
});

// Route: Add access log (simulate card swipe)
app.post('/swipe', (req, res) => {
    const { student_id } = req.body;
    const query = `INSERT INTO access_logs (student_id) VALUES (?)`;
    db.query(query, [student_id], (err, result) => {
        if (err) return res.status(500).send(err.message);
        res.send('Access logged');
    });
});

// Admin - View access logs
app.get('/logs', (req, res) => {
    const { student_id, from_date, to_date } = req.query;
    let query = `SELECT * FROM access_logs WHERE 1=1`;

    if (student_id) query += ` AND student_id = '${student_id}'`;
    if (from_date && to_date) query += ` AND timestamp BETWEEN '${from_date}' AND '${to_date}'`;

    db.query(query, (err, results) => {
        if (err) return res.status(500).send(err.message);
        res.render('logs', { logs: results });
    });
});

app.post('/update-status', (req, res) => {
    const { student_id, status } = req.body;
    const query = `UPDATE users SET status = ? WHERE student_id = ?`;
    db.query(query, [status, student_id], (err, result) => {
        if (err) return res.status(500).send(err.message);
        res.send(`User ${student_id} status updated to ${status}`);
    });
});


const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
